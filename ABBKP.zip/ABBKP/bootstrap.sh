#! /bin/sh 
#################################################################################
# BOOTSTRAP
#
# This is the begining of the Program. Bootstrap is a self-starting setup process 
# intended to aid the main program. The setup Process will
# 1. Define global variables
# 2. Define global functions
# 3. Configure Logging Module
#################################################################################
# Version: 1.1
# Date:    2019-08-15
# ##############################################################################
# Revision History:
# 2019-08-15 : AMOGH BADNIKAR [SAS] : Original version
# ##############################################################################
export BASE_DIR=/opt/sas/sw/SASPlatformObjectFramework/9.4
export LIB_DIR=/home/l108023/GITHUB/CRCE/2_Test/Libraries
export TBL_DIR=/home/l108023/GITHUB/CRCE/2_Test/Tables
DATETIME="`date +%Y-%m-%d` `date +%T%z`" # Date format at beginning of log entries to match RFC
DATE_FOR_FILENAME=`date +%Y%m%d%H%M%S`
HOSTNAME=metadata01.test.sas.srv.westpac.com.au
PORT=8562

#
# Logging Level configuration works as follows:
# DEBUG - Provides all logging output
# INFO  - Provides all but debug messages
# WARN  - Provides all but debug and info
# ERROR - Provides all but debug, info and warn
#
# SEVERE and CRITICAL are also supported levels as extremes of ERROR
#
SCRIPT_LOGGING_LEVEL="DEBUG"
#####      END OF GLOBAL VARIABLE CONFIGURATION      ############################
#################################################################################
# SCRIPT LOGGING CONFIGURATION
#
# The following is used by the script to output log data. Depending upon the log
# level indicated, more or less data may be output, with a "lower" level
# providing more detail, and the "higher" level providing less verbose output.
# LOGGING
#
# Calls to the logThis() function will determine if an appropriate log file
# exists. If it does, then it will use it, if not, a call to openLog() is made,
# if the log file is created successfully, then it is used.
#
# All log output is comprised of
# [+] An RFC 3339 standard date/time stamp
# [+] The declared level of the log output
# [+] The runtime process ID (PID) of the script
# [+] The log message
#################################################################################
function openLog {
    echo -e "${DATETIME} : PID $$ : INFO : New log file (${logFile}) created." >> "${SCRIPT_LOGFILE}"

    if ! [[ "$?" -eq 0 ]]
    then
        echo "${DATETIME} - ERROR : UNABLE TO OPEN LOG FILE - EXITING SCRIPT." >> "${SCRIPT_LOGFILE}"
        exit 1
    fi
}

function logThis() 
{
    DATETIME=$(date --rfc-3339=seconds)
    if [[ -z "${1}" || -z "${2}" ]]
    then
        echo "${DATETIME} - ERROR : LOGGING REQUIRES A DESTINATION FILE, A MESSAGE AND A PRIORITY, IN THAT ORDER."  >> "${SCRIPT_LOGFILE}"
        echo "${DATETIME} - ERROR : INPUTS WERE: ${1} and ${2}."  >> "${SCRIPT_LOGFILE}"
        exit 1
    fi

    LOG_MESSAGE="${1}"
    LOG_PRIORITY="${2}"

    # Determine if logging level is supported and desired
    #
    # This seems more complex than may be necessary
    if [[ ${LOG_PRIORITY} -eq "DEBUG" ]] && [[ ${SCRIPT_LOGGING_LEVEL} -eq "DEBUG" ]]
    then
        LOG_PRIORITY_SUPPORTED=true
    elif [[ ${LOG_PRIORITY} -eq "INFO" ]] && [[ ${SCRIPT_LOGGING_LEVEL} -eq "DEBUG"||"INFO" ]]
    then
        LOG_PRIORITY_SUPPORTED=true
    elif [[ ${LOG_PRIORITY} -eq "WARN" ]] && [[ ${SCRIPT_LOGGING_LEVEL} -eq "DEBUG"||"INFO"||"WARN" ]]
    then
        LOG_PRIORITY_SUPPORTED=true
    elif [[ ${LOG_PRIORITY} -eq "ERROR"||"SEVERE"||"CRITICAL" ]] && [[ ${SCRIPT_LOGGING_LEVEL} -eq "DEBUG"||"INFO"||"WARN"||"ERROR"||"SEVERE"||"CRITICAL" ]]
    then
        LOG_PRIORITY_SUPPORTED=Fail
    else
        echo -e "CRITICAL: Declared log priority is not supported."  >> "${SCRIPT_LOGFILE}"
        exit 1
    fi

    # If logging level NOT supported, dump it
    if ! [ ${LOG_PRIORITY_SUPPORTED} ]
    then
        echo "priority unsupported"
        break
    fi
	
	if [ "${LOG_PRIORITY_SUPPORTED}" ==  "Fail" ]
	then
	        exit 99
	fi

    # No log file, create it.
    if ! [[ -f ${SCRIPT_LOGFILE} ]]
    then
        echo -e "INFO : No log file located, creating new log file (${SCRIPT_LOGFILE})."  >> "${SCRIPT_LOGFILE}"
        echo "${DATETIME} : PID $$ :INFO : No log file located, creating new log file (${SCRIPT_LOGFILE})." >> "${SCRIPT_LOGFILE}"
        openLog
    fi

    # Write log details to file
    echo -e "${LOG_PRIORITY} : ${LOG_MESSAGE}"  >> "${SCRIPT_LOGFILE}"
    echo -e "${DATETIME} : PID $$ : ${LOG_PRIORITY} : ${LOG_MESSAGE}" >> "${SCRIPT_LOGFILE}"

    # Reset log level support flag
    LOG_PRIORITY_SUPPORTED=false
}

#################################################################################
# Read Input Parameters
# Username/Password should be suplied by the end user, following  finction will
# read the command line arguments.The program will gracefully exit the execution 
# cycle if any command line argument is missing
#################################################################################

function error_exit()
{
    if [ $? -ne 0 ] 
    then
        logThis "${1}" "ERROR"
    fi
}

function read_input() 
{

    metauser=$1
    export metauser
    metapass=$2
    export metapass
    objectname=$3

    if [ -z "${metauser}" ] || [ -z "${metapass}" ] || [ -z "${objectname}" ] 
    then
         echo -e "Aleast one of the input parameter is missing ..Exiting Gracefully .." 
         exit 99
    fi

}


function parse_input () {         
    metauser=$1
    export metauser
    metapass=$2
    export metapass    
    propfile="$3"
    export propfile

    if [ ! -f "${propfile}" ]
    then
        echo -e  "Properties File ${propfile} is missing ..Exiting Gracefully .."
        exit 99
    fi
    
    export object=`awk 'BEGIN {FS = "," };{ print $1 }' "${propfile}" |awk 'NR > 1'`
    export Type=`awk 'BEGIN {FS = "," };{ print $2 }' "${propfile}" |awk 'NR > 1'`
    export mode=`awk 'BEGIN {FS = "," };{ print $3 }' "${propfile}" |awk 'NR > 1'`
    export depfolder=`awk 'BEGIN {FS = "," };{ print $4 }' "${propfile}" |awk 'NR > 1'`
    export SPK_DIR=`awk 'BEGIN {FS = "," };{ print $5 }' "${propfile}" |awk 'NR > 1'`
    export execute=`awk 'BEGIN {FS = "," };{ print $6 }' "${propfile}" |awk 'NR > 1'`
 

    #object=$3
    #export object
    #Type=$4
    #export Type	
    #mode=$5 #Export/Import	
    #export mode
    #depfolder=$7
    #export depfolder	
    #execute=$8
    #export execute

    SCRIPT_LOG_DIR="/home/l108023/Log/${mode}"
    SCRIPT_LOGFILE="${SCRIPT_LOG_DIR}/${mode}_${object}_${DATE_FOR_FILENAME}.log"
    
    logThis "Checking Input Parameters" "INFO"
        
    if [ -z "$metauser" ] || [ -z "$metapass" ] || [ -z "$object" ] || [ -z "$Type" ] || [ -z "$mode" ] || [ -z "$depfolder" ] || [ -z "$execute" ]
    then
        error_exit "Aleast one of the input parameter is not Parsed correctly Exiting Gracefully .." 
    fi

}


function exportpackage ()
{
	
        logThis "Running Export package" "INFO"

        commandline=`echo ${BASE_DIR}/ExportPackage -host "$HOSTNAME" -port ${PORT} -user "$metauser" -password "$metapass" -package "\"${SPK_DIR}/${object}.spk\"" -objects "\"${depfolder}/${object}($Type)\"" -subprop -disableX11`
        if [ "$execute" == "N" ]
        then 
            commandline=${commandline}" -noexecute >> ${SCRIPT_LOGFILE}"
            #commandline=${commandline}" -noexecute"
        else 
            commandline=${commandline}" >> \"${SCRIPT_LOGFILE}\""
        fi
	#echo "$commandline"
        eval "$commandline"
	error_exit "Export Package Failed"               
}

