#!/bin/sh 

. ./bootstrap.sh
echo ${LIB_DIR}

walk_dir () {
    shopt -s nullglob dotglob
    find "$1" -name "*properties" -print
}

Main () {

    read_input $1 $2 $3

    case "${objectname}" in
        Library)
                   echo ${LIB_DIR}
                   
                   ls ${LIB_DIR}/*properties | while IFS="#" read file
                   do                   
                      parse_input $metauser $metapass "${file}"
                      if [ "${mode}" == "Export" ]
                      then 
                          exportpackage
                      fi
                   done
            ;;
        Table)
                   walk_dir "${TBL_DIR}"
                   #ls ${TBL_DIR}/Control/*properties | while IFS="#" read file
                   #do                   
                      #parse_input $metauser $metapass "${file}"
                      #if [ "${mode}" == "Export" ]
                      #then 
                      #        exportpackage
                      #fi
                   #done
                                      
            ;;
              *)
                   echo -e "${RED}Error... Specified Object is not Part of CRCE Metadata"
                   exit 99
    esac
}
Main $1 $2 $3   
