#!/bin/ksh

# set these values to the location of the installation
#CommandToExecute=java
CommandToExecute=/opt/sas/sw/SASPrivateJavaRuntimeEnvironment/9.4/jre/bin/java
PlatformVJR=/opt/sas/sw/SASVersionedJarRepository/eclipse
SASConfigDir=/tmp/AB/
WorkingDirectory="$SASConfigDir/Reportflow"

CommandLineArgs=-Xmx512m -Djava.system.class.loader=com.sas.app.AppClassLoader -Dsas.app.class.dirs=$WorkingDirectory -Dsas.ext.config=sas.java.ext.config -cp "$PlatformVJR/plugins/sas.launcher_904400.0.0.20160427190000_v940m4/sas.launcher.jar" -Dsas.app.launch.config=genFlowReportpicklist -Djava.security.auth.login.config=Config/security/login.config -Djava.security.auth.policy=Config/security/auth.policy -Dcache.auth.policy=true -Dsas.app.repository.path="$PlatformVJR" com.sas.scheduler.cli.AppMain AppMain.class

# Default settings on the command-line arguments
 
# Command-line interface for reporting flow definitions
# Reporting a flow definition requires metadata server connection (see metadata server options) and
# SAS Application Server with Workspace server (see SAS AppServer options).
# Metadata server options: -metaserver <machine> -metaport <port> -metarepository <repositoryName> -metauser <metadata user> -metapass <metadata password>
metaserver=metadata02.disc.sas.srv.westpac.com.au
metaport=8562
metarepository=Foundation
metauser="lsf_adlvldn"
metapass="B5s8nlEREPscwzZZBL19"

# SAS AppServer options: -servermachine <machine> -serverport <port> -username <user> -password <password>
servermachine=grid01.disc.sas.srv.westpac.com.au
serverport=18592
username="lsf_adlvldn"
password="B5s8nlEREPscwzZZBL19"

# Reporting a flow definition: -flow <name> (-xml | -sas | -csv) [-outputDir <directory path>]
type=csv
OutputDirectory="$SASConfigDir/Utilities/ReportFlow/$type"
flow="wrapper1"


# process the command line arguments
typeset -l token
while true
  do
  if [[ -z "$1" ]]; then
    break;
  else
    token=$1
  fi

  case $token in
       -metas*)
              lastcommand=metaserver
              shift;
              metaserver="$1"
              ;;
       -metap*)
              lastcommand=metaport
              shift;
              metaport="$1"
              ;;
       -metapo*)
              lastcommand=metaport
              shift;
              metaport="$1"
              ;;
       -metar*)
              lastcommand=metarepository
              shift;
              metarepository="$1"
              ;;
       -metau*)
              lastcommand=metauser
              shift;
              metauser="$1"
              ;;
       -metapa*)
              lastcommand=metapass
              shift;
              metapass="$1"
              ;;
       -serverm*)
              lastcommand=servermachine
              shift;
              servermachine="$1"
              ;;
       -serverp*)
              lastcommand=serverport
              shift;
              serverport="$1"
              ;;
       -u*)
              lastcommand=username
              shift;
              username="$1"
              ;;
       -p*)
              lastcommand=password
              shift;
              password="$1"
              ;;
       -t*)
              lastcommand=type
              shift;
              type="$1"
              ;;
       -o*)
              lastcommand=output
              shift;
              OutputDirectory="$1"
              ;;
       -f*)
              lastcommand=flow
              shift;
              flow="$1"
              ;;
       -*)
              print "?(genFlowReport) Unknown option: $1";
              ;;
       *)
              print "?(genFlowReport) Unknown argument: $1";
              ;;
  esac;
  shift;
  done


metaopts="-metaserver $metaserver -metaport $metaport -metarepository $metarepository -metauser $metauser -metapass $metapass"
serveropts="-servermachine $servermachine -serverport $serverport -username $username -password $password"
reportopts="-flow $flow -$type -outputDir $OutputDirectory"


cd $WorkingDirectory
$CommandToExecute $CommandLineArgs $reportopts $metaopts $serveropts
#rc=$?
#
#if [ $rc -eq 1 ]; then
#  print "ERROR_CIRCULAR_DEPENDENCIES"
#elseif [ $rc -eq 2 ]; then
#  print "ERROR_NO_WORKSPACESERVER"
#elseif [ $rc -eq 3 ]; then
#  print "ERROR_UNABLE_TO_SUBMIT_JOB"
#elseif [ $rc -eq 4 ]; then
#  print "ERROR_UNABLE_TO_WRITE_REPORT"
#elseif [ $rc -eq 99 ]; then
#  print "ERROR_UNEXPECTED_EXCEPTION"
#fi
#
#exit $rc
