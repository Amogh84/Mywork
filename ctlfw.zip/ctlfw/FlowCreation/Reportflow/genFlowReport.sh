#!/bin/ksh

# set these values to the location of the installation
#CommandToExecute=java
CommandToExecute=/opt/sas/sw/SASPrivateJavaRuntimeEnvironment/9.4/jre/bin/java
PlatformVJR=/opt/sas/sw/SASVersionedJarRepository/eclipse
SASConfigDir=/tmp/AB
WorkingDirectory=$SASConfigDir/Reportflow

#CommandLineArgs=.:{$WorkingDirectory}\/sasmc.ini
CommandLineArgs=`cat /tmp/AB/Reportflow/sasmc.ini`
#CommandLineArgs="-Xmx512m -Djava.security.policy=/gpfs/ceifrs/sw/SASManagementConsole/9.4/Config/security/java.policy -Djava.security.auth.login.config=/gpfs/ceifrs/sw/SASManagementConsole/9.4/Config/security/login.config -Dcache.auth.policy=true -Dsas.app.splash.path=splash.gif -Dlog4j.configuration=file:/opt/sas/sw/SASManagementConsole/9.4/log4j.properties -Dsas.services.information.types.path=/opt/sas/sw/SASPlatformObjectFramework/9.4/plugins -Dsas.deployment.agent.client.config=/opt/sas/sw/SASRemoteDeploymentAgentClient/2.1/deployagtclt.properties -Djava.system.class.loader=com.sas.app.AppClassLoader -Dsas.app.class.dirs=$WorkingDirectory -Dsas.ext.config=/opt/sas/sw/sas.java.ext.config -Dsas.app.launch.config=/tmp/AB/Reportflow/genFlowReportpicklist -Dsas.app.repository.path=/tmp/AB/Reportflow com.sas.scheduler.cli.AppMain"
#CommandLineArgs=" -cp /tmp/AB/Reportflow/sas.schedule.api.jar -Xmx512m -Djava.security.policy=/gpfs/ceifrs/sw/SASManagementConsole/9.4/Config/security/java.policy -Djava.security.auth.login.config=/gpfs/ceifrs/sw/SASManagementConsole/9.4/Config/security/login.config -Dcache.auth.policy=true -Dsas.app.splash.path=splash.gif -Dlog4j.configuration=file:/opt/sas/sw/SASManagementConsole/9.4/log4j.properties -Dsas.services.information.types.path=/opt/sas/sw/SASPlatformObjectFramework/9.4/plugins -Dsas.deployment.agent.client.config=/opt/sas/sw/SASRemoteDeploymentAgentClient/2.1/deployagtclt.properties -Djava.system.class.loader=com.sas.app.AppClassLoader -Dsas.app.class.dirs=$WorkingDirectory -Dsas.ext.config=/opt/sas/sw/sas.java.ext.config -Dsas.app.launch.config=/tmp/AB/Reportflow/genFlowReportpicklist -Dsas.app.repository.path=/tmp/AB/Reportflow/sas.schedule.api.jar tmp.com.sas.scheduler.api.report.ReportFlowToCSV"

# Default settings on the command-line arguments

 
# Command-line interface for reporting flow definitions
# Reporting a flow definition requires metadata server connection (see metadata server options) and
# SAS Application Server with Workspace server (see SAS AppServer options).
# Metadata server options: -metaserver <machine> -metaport <port> -metarepository <repositoryName> -metauser <metadata user> -metapass <metadata password>
metaserver=metadata02.disc.sas.srv.westpac.com.au
metaport=8562
metarepository=Foundation
metauser="lsf_adlvldn"
metapass="B5s8nlEREPscwzZZBL19"

# SAS AppServer options: -servermachine <machine> -serverport <port> -username <user> -password <password>
servermachine=grid01.disc.sas.srv.westpac.com.au
serverport=18592
username="lsf_adlvldn"
password="B5s8nlEREPscwzZZBL19"

# Reporting a flow definition: -flow <name> (-xml | -sas | -csv) [-outputDir <directory path>]
type=csv
OutputDirectory="$SASConfigDir/ReportFlow/$type"
flow="wrapper1"


# process the command line arguments
typeset -l token
while true
  do
  if [[ -z "$1" ]]; then
    break;
  else
    token=$1
  fi

  case $token in
       -metas*)
              lastcommand=metaserver
              shift;
              metaserver="$1"
              ;;
       -metap*)
              lastcommand=metaport
              shift;
              metaport="$1"
              ;;
       -metapo*)
              lastcommand=metaport
              shift;
              metaport="$1"
              ;;
       -metar*)
              lastcommand=metarepository
              shift;
              metarepository="$1"
              ;;
       -metau*)
              lastcommand=metauser
              shift;
              metauser="$1"
              ;;
       -metapa*)
              lastcommand=metapass
              shift;
              metapass="$1"
              ;;
       -serverm*)
              lastcommand=servermachine
              shift;
              servermachine="$1"
              ;;
       -serverp*)
              lastcommand=serverport
              shift;
              serverport="$1"
              ;;
       -u*)
              lastcommand=username
              shift;
              username="$1"
              ;;
       -p*)
              lastcommand=password
              shift;
              password="$1"
              ;;
       -t*)
              lastcommand=type
              shift;
              type="$1"
              ;;
       -o*)
              lastcommand=output
              shift;
              OutputDirectory="$1"
              ;;
       -f*)
              lastcommand=flow
              shift;
              flow="$1"
              ;;
       -*)
              print "?(genFlowReport) Unknown option: $1";
              ;;
       *)
              print "?(genFlowReport) Unknown argument: $1";
              ;;
  esac;
  shift;
  done


metaopts="-metaserver $metaserver -metaport $metaport -metarepository $metarepository -metauser $metauser -metapass $metapass"
serveropts="-servermachine $servermachine -serverport $serverport -username $username -password $password"
#reportopts="-flow $flow -$type -outputDir $OutputDirectory"
reportopts=" $flow -$type -outputDir $OutputDirectory"


cd $WorkingDirectory
$CommandToExecute $CommandLineArgs $reportopts $metaopts $serveropts
#rc=$?
#
#if [ $rc -eq 1 ]; then
#  print "ERROR_CIRCULAR_DEPENDENCIES"
#elseif [ $rc -eq 2 ]; then
#  print "ERROR_NO_WORKSPACESERVER"
#elseif [ $rc -eq 3 ]; then
#  print "ERROR_UNABLE_TO_SUBMIT_JOB"
#elseif [ $rc -eq 4 ]; then
#  print "ERROR_UNABLE_TO_WRITE_REPORT"
#elseif [ $rc -eq 99 ]; then
#  print "ERROR_UNEXPECTED_EXCEPTION"
#fi
#
#exit $rc

