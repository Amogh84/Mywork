#!/bin/sh 
# ------------------------------------------------------
# Purpose
# To allow Control-M to trigger SAS schedules via Platform Process Manager CLI utilities
# ------------------------------------------------------

# ------------------------------------------------------
# Version History
# ------------------------------------------------------
# v1.0  2012-06-27    Initial version by SAS [Paul Northrop]
# V2.0  2018-08-2018  Removed queue related functionality [Ananth Krishnamurthy]
# V3.0  2018-09-20    Added logic to restart a new flow on first failure [Amogh Badnikar]
# ------------------------------------------------------

# ------------------------------------------------------
# Parameters:
# ------------------------------------------------------
# FLOW = Name of Flow to trigger/re-run.  This is CASE-SENSITIVE.
# WAIT = Wait Period (time to wait between checking status of flow, default = 60 seconds)
# MODE = RUN|RERUN.  RUN is default.  
#        Use RERUN to restart a flow that has previously exited
# DEBUG = 0 or 1.  Default is 0.  If set to 1, messages are logged for running flows

# ------------------------------------------------------
# Initialise site specific environment
# ------------------------------------------------------
# Set PM_DIR to location of Process Manager
# ------------------------------------------------------
PM_DIR=/opt/sas/sw/ThirdParty/Platform/pm
. ${PM_DIR}/conf/profile.js


# ------------------------------------------------------
# Source LSF environment
# ------------------------------------------------------
LSF_DIR=/opt/sas/sw/ThirdParty/Platform/lsf
. ${LSF_DIR}/conf/profile.lsf

# ------------------------------------------------------
# Set JS_ENVDIR to point to location of js.conf that has 
# JS_LOGIN_REQUIRED=false
# ------------------------------------------------------
JS_ENVDIR=${PM_DIR}/conf

# ------------------------------------------------------
# Set LOG_DIR to location where log files of this script will be created
# ------------------------------------------------------
LOG_DIR=/opt/sas/data/adletl/Lev2/2_vldn/code/ctm/logs

# ------------------------------------------------------
# Set defaults....
# ------------------------------------------------------
RC=99
FLOW=NULL
FLOWID=NULL
DEP_JOB_WAIT=15 
STATUS=INIT
WAIT=10
MODE=RUN
DEBUG=0
TMP_FILE=NULL
LOG_FILE=NULL
ACTION=NULL
LOG_DT=`date +%Y%m%d_%H%M%S`
MAIN_LOG_FILE=$LOG_DIR/${flow_name}_${LOG_DT}.log


# ------------------------------------------------------
# Define script functions
# ------------------------------------------------------

function setLogHeader {
  LOG_HEADER=`date +%Y-%m-%d\ %H:%M:%S`
  LOG_HEADER="$LOG_HEADER : ${USER} : ${FLOW} : ${FLOWID} : ${STATUS} :"
  export LOG_HEADER
}


function get_flow_status {
  jdefs $FLOW | grep $FLOWID > $TMP_FILE
  STATUS=`awk -F '\\\\(|\\\\)' '// {print $2}' $TMP_FILE`
  setLogHeader
}
 

function wait_for_flow {
  sleep $WAIT_PERIOD
  setLogHeader
  get_flow_status
  
  if [ "$STATUS" = "Killed" ]
    then
      RC=12
      echo ${LOG_HEADER} INFO: Flow has been killed. >> $MAIN_LOG_FILE
      return
  fi
  if [ "$STATUS" = "Done" ]
    then
      RC=0
      echo ${LOG_HEADER} INFO: Flow has completed successfully. >> $MAIN_LOG_FILE
      return
  fi

  if [ "$STATUS" = "Exit" ]
    then
      echo ${LOG_HEADER} ERROR: Flow has ended with WARNINGS OR ERRORS. Exiting RC=12. >> $MAIN_LOG_FILE
      RC=12
      return
  else
    if [ $DEBUG -eq 1 ]
      then
        echo ${LOG_HEADER} INFO: Current status is $STATUS >> $MAIN_LOG_FILE
    fi
    wait_for_flow
  fi
}
 

function clean_up {

  if [ -e $LOG_FILE  ]
    then
        rm $LOG_FILE
  fi

  if [ -e $TMP_FILE ]
    then
        rm $TMP_FILE
  fi

  return
}


function get_flowid {
  TMP_FILE=${LOG_DIR}/_getflowid_$$.txt
  TMP_FILE1=${LOG_DIR}/_getflowid_$$_1.txt
  TMP_FILE2=${LOG_DIR}/_getflowid_$$_2.txt


  jdefs -u $USER ${FLOW} > $TMP_FILE

  runcount=`cat $TMP_FILE |wc -l`
  
  case $runcount in 
        1|2)
	   tail -1 $TMP_FILE > $TMP_FILE1
           export FLOWID=`cat $TMP_FILE1|awk '{print $4}'|cut -d'(' -f1`
	   FLOWSTATUS=`cat $TMP_FILE1|awk '{print $4}'|cut -d'(' -f2|cut -d')' -f1`
           touch $TMP_FILE2
        ;;
	
	*)
          tail -1 $TMP_FILE > $TMP_FILE1
          FLOWID=`awk '{print $1}' $TMP_FILE1`
          echo $FLOWID > $TMP_FILE1
          export FLOWID=`awk -F '(' '{print $1}' $TMP_FILE1`
          FLOWSTATUS=`awk -F '(' '{print $2}' $TMP_FILE1`
          echo $FLOWSTATUS> $TMP_FILE2
          FLOWSTATUS=`awk -F ')' '{print $1}' $TMP_FILE2`
        ;;
  esac


  if [ "Exit" != "$FLOWSTATUS" ]
    then
      STATUS=ERROR_CANNOTRERUN 
      setLogHeader
      echo "${LOG_HEADER} ERROR: Cannot Restart flow ID($FLOWID) - current state is $FLOWSTATUS" >> $MAIN_LOG_FILE
      exit 10
  fi
 
  rm $TMP_FILE $TMP_FILE1 $TMP_FILE2
  return
}

# ########################################
# MAIN
# ########################################

setLogHeader

# ------------------------------------------------------
# Check Log directory can be written to, exit if false
# ------------------------------------------------------
if [ ! -w $LOG_DIR ]
  then
    echo "ERROR: Cannot write to log directory (${LOG_DIR})"
    exit 10
fi

# ------------------------------------------------------
# Process Command Line Parameters
# ------------------------------------------------------
for arg in "$@"
  do
    export $arg
  done



# ------------------------------------------------------
# If MAIN_LOG_FILE does not exist, create it and write header records
# ------------------------------------------------------
if [ ! -e $MAIN_LOG_FILE ]
  then
    echo "******************************************************************************" >> $MAIN_LOG_FILE
    echo "* trigger_flow log file for flows triggered on `date +%Y-%m-%d`               " >> $MAIN_LOG_FILE
    echo "* Created on `date +%Y-%m-%d\ %H:%M:%S`                                       " >> $MAIN_LOG_FILE
    echo "******************************************************************************" >> $MAIN_LOG_FILE
    echo "*Timestamp          : User ID : Flow Name    : Flow ID : Status : Message Type : Message" >> $MAIN_LOG_FILE
    echo "******************************************************************************" >> $MAIN_LOG_FILE
    chmod g+w $MAIN_LOG_FILE
fi

function validate_parameters {
# ------------------------------------------------------
# Validate parameters...
# ------------------------------------------------------

if [ "$FLOW" = "NULL" ]
  then
    # No flow name or queue provided, so exit
    STATUS=ERROR
    setLogHeader
    echo ${LOG_HEADER} ERROR: No FLOW= parameter has been passed. Exiting RC=10 >> $MAIN_LOG_FILE
    exit 10
fi


if [ "$FLOW" = "NULL" -a "$MODE" = "RERUN" ]
  then
        echo ${LOG_HEADER} ERROR: No FLOW= parameter has been passed for MODE=${MODE}. Exiting RC=10 >> $MAIN_LOG_FILE
        exit 10
  else
    setLogHeader
    echo ${LOG_HEADER} INFO: Script initialised with command $0 $* >> $MAIN_LOG_FILE
fi


LOG_FILE=$LOG_DIR/${FLOW}.log
if [ -e $LOG_FILE ] 
  then
    # Delete existing log file
    rm $LOG_FILE
    RC=$?
    if [ $RC -ne 0 ] 
      then
        STATUS=ACCESS_ERROR
        setLogHeader
        echo ${LOG_HEADER} ACCESS: User does not have write permission to ${LOG_FILE}. Exiting RC=10 >> $MAIN_LOG_FILE
        exit 10
    fi
fi
}

validate_parameters    

# ------------------------------------------------------
# Set the WAIT_PERIOD if not specified on command line...
# ------------------------------------------------------
if [ "x$WAIT" = "x" ]
  then
    WAIT_PERIOD=60
else
    WAIT_PERIOD=$WAIT
fi


# ------------------------------------------------------
# Trigger or rerun the flow...
# ------------------------------------------------------
if [ "$MODE" = "RUN" ]
  then 
    
    jtrigger -v "LSF_RUN_NUMBER=$run_number" $FLOW > $LOG_FILE 2>/dev/null
    RC=$?

    if [ $RC -ne 0 ]
      then
        STATUS=ERROR_START
        setLogHeader
        echo ${LOG_HEADER} ERROR: Flow ${FLOW} cannot be triggered. jtrigger return code is $RC. Exiting with RC=10 >> $MAIN_LOG_FILE
        clean_up
        exit 10
    fi
    FLOWID=`awk -F '<|>' '/:/ {print $4}' $LOG_FILE`

    if [ "x$FLOWID" = "x" ]
      then
        STATUS=ERROR_INIT
        setLogHeader
        echo ${LOG_HEADER} ERROR: Flow ID cannot be determined. Exiting with RC=10 >> $MAIN_LOG_FILE
        clean_up
        exit 10
    fi

    STATUS=START
    setLogHeader
    echo ${LOG_HEADER} INFO: LSF Flow ID is $FLOWID... >> $MAIN_LOG_FILE

else
  if [ "$MODE" = "RERUN" ]
    then 
      STATUS=GET_FLOWID
      setLogHeader
      get_flowid
      jrerun -v "LSF_RUN_NUMBER=$run_number" $FLOWID > $LOG_FILE 2>/dev/null
      RC=$?
      if [ $RC -ne 0 ]
        then
          STATUS=ERROR_START
          setLogHeader
          echo ${LOG_HEADER} ERROR: Flow ID ${FLOWID} cannot be rerun. jrerun return code is $RC. Exiting with RC=10 >> $MAIN_LOG_FILE
          clean_up
          exit 10
      fi

  else
      RC=10
  fi
fi
    

export TMP_FILE=${LOG_DIR}/_tmp_${FLOWID}.txt


wait_for_flow


# ##########################################################
# Clean Up...
# ##########################################################
clean_up

exit $RC

